var hoverDistort = new hoverEffect({
  parent: document.querySelector(".liquid-distortion"),
  intensity: 0.5,
  image1: "../assets/img/slider/7.jpg",
  image2: "../assets/img/slider/9.jpg",
  displacementImage: "../assets/img/slider/displacement/1.jpg"
});

var button = new hoverEffect({
  parent: document.querySelector(".project-distortion-video-1"),
  image1: "../assets/img/projects/1.mp4",
  image2: "../assets/img/projects/2.mp4",
  displacementImage: "../assets/img/slider/displacement/2.jpg",
  video: true
});

var button = new hoverEffect({
  parent: document.querySelector(".project-distortion-video-2"),
  image1: "../assets/img/projects/2.mp4",
  image2: "../assets/img/projects/1.mp4",
  displacementImage: "../assets/img/slider/displacement/2.jpg",
  video: true
});

var hoverDistort = new hoverEffect({
  parent: document.querySelector(".project-distortion-1"),
  intensity: 0.5,
  image1: "../assets/img/projects/2/2.jpg",
  image2: "../assets/img/projects/2/1.jpg",
  displacementImage: "../assets/img/slider/displacement/2.jpg"
});

var hoverDistort = new hoverEffect({
  parent: document.querySelector(".project-distortion-2"),
  intensity: 0.5,
  image2: "../assets/img/projects/2/3.jpg",
  image1: "../assets/img/projects/2/2.jpg",
  displacementImage: "../assets/img/slider/displacement/2.jpg"
});

var hoverDistort = new hoverEffect({
  parent: document.querySelector(".project-distortion-3"),
  intensity: 0.5,
  image2: "../assets/img/projects/2/4.jpg",
  image1: "../assets/img/projects/2/3.jpg",
  displacementImage: "../assets/img/slider/displacement/2.jpg"
});

var hoverDistort = new hoverEffect({
  parent: document.querySelector(".project-distortion-4"),
  intensity: 0.5,
  image2: "../assets/img/projects/2/5.jpg",
  image1: "../assets/img/projects/2/4.jpg",
  displacementImage: "../assets/img/slider/displacement/2.jpg"
});

var hoverDistort = new hoverEffect({
  parent: document.querySelector(".project-distortion-5"),
  intensity: 0.5,
  image2: "../assets/img/projects/2/6.jpg",
  image1: "../assets/img/projects/2/5.jpg",
  displacementImage: "../assets/img/slider/displacement/2.jpg"
});

var hoverDistort = new hoverEffect({
  parent: document.querySelector(".project-distortion-6"),
  intensity: 0.5,
  image2: "../assets/img/projects/2/7.jpg",
  image1: "../assets/img/projects/2/6.jpg",
  displacementImage: "../assets/img/slider/displacement/2.jpg"
});

var hoverDistort = new hoverEffect({
  parent: document.querySelector(".project-distortion-7"),
  intensity: 0.5,
  image2: "../assets/img/projects/2/8.jpg",
  image1: "../assets/img/projects/2/7.jpg",
  displacementImage: "../assets/img/slider/displacement/2.jpg"
});

var hoverDistort = new hoverEffect({
  parent: document.querySelector(".project-distortion-8"),
  intensity: 0.5,
  image2: "../assets/img/projects/2/1.jpg",
  image1: "../assets/img/projects/2/8.jpg",
  displacementImage: "../assets/img/slider/displacement/2.jpg"
});